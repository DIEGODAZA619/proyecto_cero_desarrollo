<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['plans']='计划';
    $lang['recommended']='推荐的';
    $lang['binary']='二进制';
    $lang['career_plan']='职业规划';
    $lang['points']='积分';
    $lang['affiliate_network']='附属网络';
    $lang['binary_earnings']='二元收益';
    $lang['daily_earnings']='每日收入';
    $lang['purchase']='购买';
?>



<?php //echo lang('plans')?>