<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['career_plans']='네트워크 > 경력 계획';
    $lang['career_plains']='경력 계획 ';
    $lang['points']='포인트';
    $lang['descrip']='설명';


?>



<?php //echo lang('plans')?>