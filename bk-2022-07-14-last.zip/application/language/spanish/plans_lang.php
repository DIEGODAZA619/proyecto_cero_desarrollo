<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['plans']='PLANES';
    $lang['recommended']='RECOMENDADO';
    $lang['binary']='Binario';
    $lang['career_plan']='Planes de Carrera';
    $lang['points']='Puntos';
    $lang['affiliate_network']='Red Afiliada';
    $lang['binary_earnings']='Ganancias Binarias';
    $lang['daily_earnings']='Ganancias Diarias';
    $lang['purchase']='Compra';
?>



<?php //echo lang('plans')?>