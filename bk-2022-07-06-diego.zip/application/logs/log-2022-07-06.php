<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>ERROR - 2022-07-06 07:09:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:47 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:09:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:10:05 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:17:22 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:21:01 --> Severity: Notice --> Undefined variable: rolescero /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:21:01 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:21:34 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:21:51 --> Severity: Notice --> Undefined variable: rolescero /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:21:52 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:22:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:31 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:51 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:22:54 --> Severity: Notice --> Undefined variable: rolescero /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:22:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/themetabiz.io/app.themetabiz.io/application/views/admin/templates/template.php 202
ERROR - 2022-07-06 07:22:55 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-06 07:23:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:23:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:23:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:23:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:24:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:24:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:24:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-06 07:24:12 --> 404 Page Not Found: Assets/template
