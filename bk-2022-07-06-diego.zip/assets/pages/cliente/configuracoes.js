//$(document).ready(function(){
    //jQuery(function($){
       //$("#celular").mask("(99) 99999-999?9");
      // $("#cpf").mask("999.999.999-999999");
   // });
//});