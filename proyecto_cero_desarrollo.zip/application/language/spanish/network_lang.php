<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['bynary_network']='Red Binaria';
    $lang['boton1']='Volver a mi red';
    $lang['boton2']='Subir un Nivel';


?>



<?php //echo lang('plans')?>