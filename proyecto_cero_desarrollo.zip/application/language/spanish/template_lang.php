<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['menu_item1']='Panel de Control';
    $lang['menu_item2']='Planes';
    $lang['menu_item3']='Red';
    $lang['menu_item4']='Pendiente';
    $lang['menu_item5']='Red Binaria';
    $lang['menu_item6']='Carrera de Planes';
    $lang['menu_item7']='Finanzas';
    $lang['menu_item8']='Soporte/Ticket';
    $lang['menu_item9']='Perfil';
    $lang['menu_item10']='Cerrar Sesión';


?>