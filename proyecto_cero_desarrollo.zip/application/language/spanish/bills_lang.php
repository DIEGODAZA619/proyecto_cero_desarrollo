<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['invoices']='Facturas';
    $lang['plan']='Plan';
    $lang['price']='Precio';
    $lang['check']='Verifica Etherscan';
    $lang['state']='Estado';
    $lang['voucher']='Cupón';

?>



<?php //echo lang('plans')?>