<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['invoices']='财务>发票';
    $lang['plan']='计划';
    $lang['price']='价格';
    $lang['check']='检查 Etherscan';
    $lang['state']='状态';
    $lang['voucher']='代金券';

?>



<?php //echo lang('plans')?>