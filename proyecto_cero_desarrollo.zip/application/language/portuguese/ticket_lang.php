<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['support']='Suporte';
    $lang['create']='Criar Ticket';
    $lang['subject']='Assunto';
    $lang['last_update']='Último update';
    $lang['status']='Status';
    $lang['toview']='Ver';
    $lang['closed']='Fechado';
?>



<?php //echo lang('plans')?>