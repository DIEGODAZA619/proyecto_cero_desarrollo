<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['title_dialog1']='Notificações';    
    $lang['welcome_dialog1']='Bem-vindo';
    $lang['title_dialog2']='Meus Pontos';
    $lang['htleft_table']="Esquerda";
    $lang['htright_table']="Certa";
    $lang['httotal_table']="Total";
    $lang['title_dialog3']="Total de Pontos";
    $lang['title_dialog4']="Pontos a Transferir";
    $lang['profits']="Lucros";
    $lang['referral_bonus']="Bônus de referência";
    $lang['rank']="Classificação";
    $lang['business_plan']="Plano de negócios";
    $lang['my_network']="Minha rede";
    $lang['sponsor']="Patrocinador";
    $lang['title_dialog5']="Lucro total";
    $lang['progress']="PROGRESSO";
    $lang['goal']="META";
    $lang['title_dialog6']="Planejar o tempo";
    $lang['expire']="Hora de expirar seu plano";
    $lang['title_dialog7']="Referencias diretas";
    $lang['ht_name']="Nome";
    $lang['ht_email']="O Email";
    $lang['ht_plan']="Plano";
    $lang['ht_phone']="Telefone";
    $lang['ht_date']="Data de registo";
    $lang['title_dialog8']="Link de recomendação";
    $lang['button1']="Link de cópia";
    $lang['button2']="Altere a chave binária e controle todos os usuários em sua rede";
    $lang['binary_key']="CHAVE BINÁRIA";
    $lang['ht_market']="MERCADO";
    $lang['ht_sell']="COMPRA/VENDA";
    $lang['ht_id']="ID";
    $lang['ht_eth_quantity']="ETH QUANTIDADE";
    $lang['ht_total_quantity']="TOTAL";


?>