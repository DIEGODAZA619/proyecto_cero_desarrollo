<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['bynary_network']='네트워크 > 바이너리 네트워크';
    $lang['boton1']='내 네트워크로 돌아가기';
    $lang['boton2']='한 수준 뒤로 이동';


?>



<?php //echo lang('plans')?>