<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['plans']='계획';
    $lang['recommended']='권장';
    $lang['binary']='바이너리';
    $lang['career_plan']='진로 계획';
    $lang['points']='포인트';
    $lang['affiliate_network']='제휴 네트워크';
    $lang['binary_earnings']='바이너리 수익';
    $lang['daily_earnings']='일일 수입';
    $lang['purchase']='구매';
?>



<?php //echo lang('plans')?>