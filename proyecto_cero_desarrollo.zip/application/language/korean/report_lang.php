<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['earnings_report']='수익 보고서';
    $lang['descrip']='설명';
    $lang['price']='가격';
    $lang['date']='날짜';

?>



<?php //echo lang('plans')?>