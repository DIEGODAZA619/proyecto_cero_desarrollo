<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['support']='Soporte';
    $lang['create']='Crear boleto';
    $lang['subject']='Assunto';
    $lang['last_update']='Última actualización';
    $lang['status']='Sujeto';
    $lang['toview']='Ver';
    $lang['closed']='Cerrar';
?>



<?php //echo lang('plans')?>