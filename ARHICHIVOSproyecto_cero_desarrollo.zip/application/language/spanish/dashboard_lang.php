<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['title_dialog1']='Notificaciones';    
    $lang['welcome_dialog1']='Bienvenido';
    $lang['title_dialog2']='Mis Puntos';
    $lang['htleft_table']="Izquierda";
    $lang['htright_table']="Derecha";
    $lang['httotal_table']="Total";
    $lang['title_dialog3']="Total de Puntos";
    $lang['title_dialog4']="Puntos para Transferir";
    $lang['profits']="Beneficios";
    $lang['referral_bonus']="Bono Recomendación";
    $lang['rank']="Rango";
    $lang['business_plan']="Plan de negocios";
    $lang['my_network']="Mi Red";
    $lang['sponsor']="Patrocinador";
    $lang['title_dialog5']="Beneficio total";
    $lang['progress']="PROGRESO";
    $lang['goal']="META";
    $lang['title_dialog6']="Tiempo del Plan";
    $lang['expire']="Tiempo que expirara tu plan";
    $lang['title_dialog7']="Referencias directas";
    $lang['ht_name']="Nombre";
    $lang['ht_email']="Correo";
    $lang['ht_plan']="Plan";
    $lang['ht_phone']="Teléfono";
    $lang['ht_date']="Fecha de Registro";
    $lang['title_dialog8']="Enlace de recomendación";
    $lang['button1']="Copiar Link";
    $lang['button2']="Cambie la clave binaria y controle a todos los usuarios de su red";
    $lang['binary_key']="CLAVE BINARIA";
    $lang['ht_market']="MERCADO";
    $lang['ht_sell']="COMPRA/VENTA";
    $lang['ht_id']="ID";
    $lang['ht_eth_quantity']="ETH CANTIDAD";
    $lang['ht_total_quantity']="TOTAL";

?>