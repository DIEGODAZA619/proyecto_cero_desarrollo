<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['career_plans']='Planes de Carrera';
    $lang['career_plains']='Planes de Carrera';
    $lang['points']='Puntos';
    $lang['descrip']=' Descripción';


?>



<?php //echo lang('plans')?>