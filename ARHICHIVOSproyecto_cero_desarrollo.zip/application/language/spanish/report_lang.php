<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['earnings_report']='Reporte de ganancias';
    $lang['descrip']='Descripción';
    $lang['price']='Precio';
    $lang['date']='Fecha';

?>



<?php //echo lang('plans')?>