<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['support']='支持';
    $lang['create']='创建工单';
    $lang['subject']='主题';
    $lang['last_update']='最后更新';
    $lang['status']='地位';
    $lang['toview']='查看';
    $lang['closed']='关闭的票';
?>



<?php //echo lang('plans')?>