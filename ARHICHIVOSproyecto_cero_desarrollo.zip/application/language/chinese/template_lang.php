<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['menu_item1']='仪表板';
    $lang['menu_item2']='计划';
    $lang['menu_item3']='网络';
    $lang['menu_item4']='待办的';
    $lang['menu_item5']='二进制网络';
    $lang['menu_item6']='职业规划';
    $lang['menu_item7']='金融';
    $lang['menu_item8']='支持/票';
    $lang['menu_item9']='轮廓';
    $lang['menu_item10']='登出';


?>