<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['career_plans']='职业规划';
    $lang['career_plains']='职业平原';
    $lang['points']='积分';
    $lang['descrip']='描述点';


?>



<?php //echo lang('plans')?>