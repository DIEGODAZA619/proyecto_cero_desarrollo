<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['bynary_network']='网络>二元网络';
    $lang['boton1']='回到我的网络';
    $lang['boton2']='返回一级';


?>



<?php //echo lang('plans')?>