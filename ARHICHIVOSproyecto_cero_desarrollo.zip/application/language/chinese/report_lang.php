<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['earnings_report']='财务>报告';
    $lang['descrip']='描述';
    $lang['price']='价格';
    $lang['date']='日期';

?>



<?php //echo lang('plans')?>