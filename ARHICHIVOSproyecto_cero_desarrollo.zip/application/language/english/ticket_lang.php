<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['support']='Support';
    $lang['create']='Create Ticket';
    $lang['subject']='Subject';
    $lang['last_update']='Last Update';
    $lang['status']='Status';
    $lang['toview']='To view';
    $lang['closed']='Closed Ticket';
?>



<?php //echo lang('plans')?>