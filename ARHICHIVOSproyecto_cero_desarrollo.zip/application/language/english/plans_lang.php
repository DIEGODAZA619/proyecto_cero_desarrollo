<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['plans']='PLANS';
    $lang['recommended']='RECOMMENDED';
    $lang['binary']='Binary';
    $lang['career_plan']='Career Plan';
    $lang['points']='points';
    $lang['affiliate_network']='Affiliate Network';
    $lang['binary_earnings']='Binary Earnings';
    $lang['daily_earnings']='Daily Earnings';
    $lang['purchase']='PURCHASE';
?>



<?php echo lang('plans')?>