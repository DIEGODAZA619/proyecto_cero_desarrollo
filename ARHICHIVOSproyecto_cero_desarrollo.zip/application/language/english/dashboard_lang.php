<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['title_dialog1']='Notifications';
    $lang['welcome_dialog1']='Welcome';
    $lang['title_dialog2']="My Points";
    $lang['htleft_table']="Left";
    $lang['htright_table']="Right";
    $lang['httotal_table']="Total";
    $lang['title_dialog3']="Total Points";
    $lang['title_dialog4']="Points to Transfer";
    $lang['profits']="Profits";
    $lang['referral_bonus']="Referral Bonus";
    $lang['rank']="Rank";
    $lang['business_plan']="Business Plan";
    $lang['my_network']="My Network";
    $lang['sponsor']="Sponsor";
    $lang['title_dialog5']="Total Profit";
    $lang['progress']="PROGRESS";
    $lang['goal']="GOAL";
    $lang['title_dialog6']="Plan Time";
    $lang['expire']="Time to expire your plan";
    $lang['title_dialog7']="Direct Referrals";
    $lang['ht_name']="Name";
    $lang['ht_email']="Email";
    $lang['ht_plan']="Plan";
    $lang['ht_phone']="Phone";
    $lang['ht_date']="Register Date";
    $lang['title_dialog8']="Recommendation Link";
    $lang['button1']="Copy Link";
    $lang['button2']="Change the binary key and control every user on your network";
    $lang['binary_key']="BINARY KEY";
    $lang['ht_market']="MARKET";
    $lang['ht_sell']="BUY/SELL";
    $lang['ht_id']="ID";
    $lang['ht_eth_quantity']="ETH QUANTITY";
    $lang['ht_total_quantity']="TOTAL";

?>