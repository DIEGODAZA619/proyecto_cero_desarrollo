<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['career_plans']='Career Plans';
    $lang['career_plains']='Career Plains';
    $lang['points']='Points';
    $lang['descrip']='Description';


?>



<?php //echo lang('plans')?>