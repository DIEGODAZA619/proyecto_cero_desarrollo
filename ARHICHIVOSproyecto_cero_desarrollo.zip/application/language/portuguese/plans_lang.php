<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['plans']='PLANOS';
    $lang['recommended']='RECOMENDADO';
    $lang['binary']='Binário';
    $lang['career_plan']='Plano de Carreira';
    $lang['points']='Pontos';
    $lang['affiliate_network']='Rede Afiliada';
    $lang['binary_earnings']='Ganhos Binários';
    $lang['daily_earnings']='Rendimentos Diários';
    $lang['purchase']='Comprar';
?>



<?php //echo lang('plans')?>