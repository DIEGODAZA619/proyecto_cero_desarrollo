<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['menu_item1']='Painel de Controle';
    $lang['menu_item2']='Planos';
    $lang['menu_item3']='Rede';
    $lang['menu_item4']='Pendente';
    $lang['menu_item5']='Rede Binária';
    $lang['menu_item6']='Planos de carreira';
    $lang['menu_item7']='Finança';
    $lang['menu_item8']='Suporte/Ticket';
    $lang['menu_item9']='Perfil';
    $lang['menu_item10']='Sair';



?>