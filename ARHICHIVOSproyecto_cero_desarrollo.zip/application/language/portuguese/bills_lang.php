<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['invoices']='Nota Fiscal';
    $lang['plan']='Plano';
    $lang['price']='Preço';
    $lang['check']='Verifica Etherscan';
    $lang['state']='Estado';
    $lang['voucher']='Cupom';

?>



<?php //echo lang('plans')?>