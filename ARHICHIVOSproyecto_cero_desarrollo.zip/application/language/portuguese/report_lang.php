<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['earnings_report']='Relatório de Ganhos';
    $lang['descrip']='Descrição';
    $lang['price']='Preço';
    $lang['date']='Data';

?>



<?php //echo lang('plans')?>