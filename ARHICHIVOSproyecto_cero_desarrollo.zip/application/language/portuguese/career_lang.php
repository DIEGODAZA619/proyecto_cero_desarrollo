<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['career_plans']='Planos de Carreira';
    $lang['career_plains']='Planos de Carreira';
    $lang['points']='Pontos';
    $lang['descrip']=' Descrição';


?>



<?php //echo lang('plans')?>