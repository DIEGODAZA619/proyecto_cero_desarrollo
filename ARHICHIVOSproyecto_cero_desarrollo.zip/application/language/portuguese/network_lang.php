<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['bynary_network']='Rede Binária';
    $lang['boton1']='Voltar para minha Rede';
    $lang['boton2']='voltar um nível';


?>



<?php //echo lang('plans')?>