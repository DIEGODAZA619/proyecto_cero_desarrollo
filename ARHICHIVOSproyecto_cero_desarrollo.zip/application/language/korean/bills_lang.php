<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['invoices']='금융 > 송장';
    $lang['plan']='계획';
    $lang['price']='가격';
    $lang['check']='확인하다 Etherscan';
    $lang['state']='상태';
    $lang['voucher']='바우처';

?>



<?php //echo lang('plans')?>