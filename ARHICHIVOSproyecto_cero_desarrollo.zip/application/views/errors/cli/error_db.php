<?php
defined('BASEPATH') OR exit('No direct script access allowed');

echo "\nErro com banco de dados: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";