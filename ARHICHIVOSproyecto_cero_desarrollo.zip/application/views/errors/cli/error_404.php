<?php
defined('BASEPATH') OR exit('No direct script access allowed');

echo "\nERRO: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";