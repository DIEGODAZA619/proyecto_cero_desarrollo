<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-12 07:31:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:31:34 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:31:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 07:31:34 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 07:31:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:31:40 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:31:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 07:31:40 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 07:32:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:32:55 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:32:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:32:56 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:33:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:33:27 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:33:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:33:41 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:33:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:33:56 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:34:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:34:06 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:34:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:34:08 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:34:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:34:16 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:35:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:35:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:35:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:35:39 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:36:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:36:17 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:36:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:36:34 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:36:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:36:50 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:38:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:38:17 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:38:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:38:18 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:38:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:38:29 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:38:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:38:33 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:38:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:38:40 --> Could not find the language line "plans"
ERROR - 2022-07-12 07:59:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 07:59:45 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:15 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:00:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:36 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:00:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:37 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:00:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:00:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:00:44 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 448
ERROR - 2022-07-12 08:01:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:01:07 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:01:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:01:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:03:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:03:36 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:03:36 --> Severity: error --> Exception: Too few arguments to function Rangos::guardarExtratosGanancias(), 3 passed in C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php on line 223 and exactly 5 expected C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 423
ERROR - 2022-07-12 08:04:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:04:34 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:04:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = 46, `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:04:34'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-12 08:04:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = 46, `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:04:34'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-12 08:04:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:04:34'
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-12 08:04:34 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0.032, 1, '2022-07-12 08:04:34', 4)
ERROR - 2022-07-12 08:04:34 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0, 1, '2022-07-12 08:04:34', 5)
ERROR - 2022-07-12 08:04:34 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Pepita Perez ', 0.03, 1, '2022-07-12 08:04:34', 7)
ERROR - 2022-07-12 08:04:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '6|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:04:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-12 08:05:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:05:54 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = 46, `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = 46, `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54'
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54'
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '6|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-12 08:05:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '6|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:05:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-12 08:07:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:07:48 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ';' or ',' C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 237
ERROR - 2022-07-12 08:08:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:08:10 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:08:10 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0.032, 1, '2022-07-12 08:08:10', 11)
ERROR - 2022-07-12 08:08:10 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0, 1, '2022-07-12 08:08:10', 12)
ERROR - 2022-07-12 08:08:10 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Pepita Perez ', 0.03, 1, '2022-07-12 08:08:10', 14)
ERROR - 2022-07-12 08:08:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '13|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:08:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-12 08:13:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:13:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:13:28 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Julio Cesar |Maria Jimenes ', 0, 1, '2022-07-12 08:13:28', 17)
ERROR - 2022-07-12 08:13:28 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0.032, 1, '2022-07-12 08:13:28', 19)
ERROR - 2022-07-12 08:13:28 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0, 1, '2022-07-12 08:13:28', 20)
ERROR - 2022-07-12 08:13:28 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Pepita Perez ', 0.03, 1, '2022-07-12 08:13:28', 22)
ERROR - 2022-07-12 08:13:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '21|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:13:28', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '20'
ERROR - 2022-07-12 08:17:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:17:04 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:17:04 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Julio Cesar |Maria Jimenes ', 0.064, 1, '2022-07-12 08:17:04', 25)
ERROR - 2022-07-12 08:17:04 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0.032, 1, '2022-07-12 08:17:04', 27)
ERROR - 2022-07-12 08:17:04 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - kirusiya ', 0.032, 1, '2022-07-12 08:17:04', 28)
ERROR - 2022-07-12 08:17:04 --> Query error: Column 'id_usuario' cannot be null - Invalid query: INSERT INTO `extrato` (`id_usuario`, `mensagem`, `valor`, `tipo`, `data`, `id_ganancia_rango`) VALUES (NULL, 'Career plan bonus - Pepita Perez ', 0.03, 1, '2022-07-12 08:17:04', 30)
ERROR - 2022-07-12 08:17:04 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '29|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:17:04', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 08:19:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:19:12 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:19:12 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '37|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:19:12', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 08:21:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:16 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:21:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:17 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:21:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:25 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:21:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:26 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:27 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:21:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:21:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\financeiro\extrato.php 84
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:21:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:21:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:21:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:22:00 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-12 08:22:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:22:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:33:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:33:17 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:34:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:34:29 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '13|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 08:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-12 08:36:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:36:08 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:36:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:36:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 08:36:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:36:16 --> Could not find the language line "plans"
ERROR - 2022-07-12 08:36:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 08:36:16 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 20:29:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:29:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:29:45 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:29:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:29:48 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:30:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:30:04 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:30:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:30:15 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:30:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:30:56 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:04 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:09 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:16 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:27 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:31:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:31:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 20:35:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:35:32 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:35:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:35:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 20:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:40:29 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:40:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 20:40:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:40:51 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:40:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:40:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 20:41:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:41:22 --> Could not find the language line "plans"
ERROR - 2022-07-12 20:41:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 20:41:22 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:08:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:08:09 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 157
ERROR - 2022-07-12 22:08:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:08:32 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:08:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:08:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:08:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:08:43 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:10:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:10:23 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:10:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:10:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:10:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = 90, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:10:29'
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-12 22:10:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:10:29'
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-12 22:10:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 22:10:29 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 22:10:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:10:31 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:10:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:10:31 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:14:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:14:22 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:14:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:14:22'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-12 22:14:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 22:14:22 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 22:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:14:23 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:14:23 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:15:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:15:38 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:15:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 22:15:38 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 22:15:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:15:38 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:15:38 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = 46, `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:15:38'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:15:38 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = 46, `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:15:38'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:15:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-12 22:15:38 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-12 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:18:29 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = 46, `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = 46, `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = 2, `valor_plan` = 6000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '15', `ganancia_diaria` = 7.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 7.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = 2, `valor_plan` = 7.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '15', `ganancia_diaria` = 1500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:18:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:18:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:19:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:19:41 --> 404 Page Not Found: admin/Rangos/index
ERROR - 2022-07-12 22:19:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:19:45 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:19:45 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '15', `ganancia_diaria` = 90, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:45'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:19:45 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:45'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:19:45 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 105, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:45', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '15', `ganancia_diaria` = 90, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '15', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 6000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 6000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '15', `ganancia_diaria` = 7.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 7.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 7.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '15', `ganancia_diaria` = 1500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '15', `ganancia_diaria` = 7.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 7.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '15', `ganancia_diaria` = 1500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 3000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '15', `ganancia_diaria` = 90, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 90, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '15', `ganancia_diaria` = 45, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 45, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 3000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '15', `ganancia_diaria` = 150, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 150, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '15', `ganancia_diaria` = 45, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 3045, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '15', `ganancia_diaria` = 150, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 3150, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '15', `ganancia_diaria` = 3000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '15', `ganancia_diaria` = 1500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 4500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '15', `ganancia_diaria` = 1500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:19:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:19:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:20:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:37 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:20:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:42 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:20:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:47 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:47 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:20:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:51 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:20:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:54 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:20:54 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:54', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:20:55 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:20:55', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:20:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:56 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:20:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:58 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:20:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:22:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:22:33 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:22:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:22:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:23:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:23:05 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:23:05 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:05', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:23:06 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:06', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:23:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:23:49 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:23:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:23:50 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:23:50', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:24:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:24:33 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:24:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:24:34 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:24:34', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:25:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:25:08 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:25:08 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:08', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:25:09 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:25:09', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:26:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:26:15 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:26:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:26:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:26:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:28:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:28:46 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:28:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '40|41|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '31|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '52|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '49|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '57|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '60|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '63|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '66|67|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-12 22:28:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:28:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-12 22:32:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:32:58 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:32:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:58'
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-12 22:32:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:58'
WHERE `estado` = 1
AND `id` = '9'
ERROR - 2022-07-12 22:32:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 35, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '8|9|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '10'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '13'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '5', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '23|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '5', `ganancia_diaria` = 2.5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '20'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2.5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '20|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '23|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '24'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '5', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 15, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '36|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 50, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '5', `ganancia_diaria` = 15, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 1015, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '42|43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '5', `ganancia_diaria` = 50, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 1050, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '5', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '50|51|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '5', `ganancia_diaria` = 500, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:32:59 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 500, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:32:59', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:34:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:34:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '1|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '9'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 70, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '8|9|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '10'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '9'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 70, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '8|9|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '10'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '13'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = 2, `valor_plan` = 20, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '13'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '5', `id_patrocinador` = '4', `id_factura` = '41', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 10, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '3|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = 2, `valor_plan` = 70, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '6|7|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '16'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-12 22:34:28 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = '10', `ganancia_diaria` = 10, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 4000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:28', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 4000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '10', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '20'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '20|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '20|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '23|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '24'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '23|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '1791', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = '10', `ganancia_diaria` = 5, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '20'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 5, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '20|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '25|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '23|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '24'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '28|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 60, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = 2, `valor_plan` = 60, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = '10', `ganancia_diaria` = 60, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 60, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '10', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '10', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 30, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '36|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '36|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 2000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '36|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '10', `ganancia_diaria` = 100, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 100, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = 2, `valor_plan` = 100, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '10', `ganancia_diaria` = 100, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 100, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '39|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '10', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 2030, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '42|43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = 2, `valor_plan` = 2030, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '42|43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = '10', `ganancia_diaria` = 30, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 2030, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '42|43|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '10', `ganancia_diaria` = 100, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 2100, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = 2, `valor_plan` = 2100, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = '10', `ganancia_diaria` = 100, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 2100, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '46|47|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 3000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '50|51|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = 2, `valor_plan` = 3000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '50|51|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = '10', `ganancia_diaria` = 2000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 3000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '50|51|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = '10', `ganancia_diaria` = 1000, `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29'
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-12 22:34:29 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = 2, `valor_plan` = 1000, `ganancia_diaria` = 1, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '54|', `fecha_calculo` = '2022-07-12', `fecha_recalculo` = '2022-07-12 22:34:29', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-12 22:36:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:36:21 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:39:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:39:43 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:41:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:41:28 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:41:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:41:43 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:41:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:41:43 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 22:41:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:41:59 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:42:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:42:13 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:42:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:42:50 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:45:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:45:01 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:46:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:46:05 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:48:57 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:49:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:49:04 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:52:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:52:46 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:54:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:54:03 --> Severity: error --> Exception: syntax error, unexpected '$datosExtrato' (T_VARIABLE), expecting ';' or ',' C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 469
ERROR - 2022-07-12 22:54:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:54:08 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:55:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:55:09 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:55:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:55:58 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:56:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:56:18 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:56:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:56:34 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:57:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:57:17 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:57:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:57:22 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:57:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:57:42 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:57:50 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:58:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:58:16 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:58:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:58:33 --> Could not find the language line "plans"
ERROR - 2022-07-12 22:58:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 22:58:52 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:00:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:00:24 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:19:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:19:55 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:19:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:19:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 23:19:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:19:58 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:19:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:19:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 23:36:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:36:52 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:36:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:36:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 23:36:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:36:57 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:36:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:36:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 23:37:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:37:00 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:37:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:37:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-12 23:37:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:37:13 --> Could not find the language line "plans"
ERROR - 2022-07-12 23:37:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-12 23:37:13 --> 404 Page Not Found: Vendor/needim
