<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-11 00:57:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:57:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:57:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:57:59 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 00:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:58:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 00:58:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:58:13 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 00:58:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 00:58:13 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-11 01:33:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:33:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:33:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:33:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:33:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:34:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:34:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:34:11 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 75
ERROR - 2022-07-11 01:35:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:04 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:10 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:10 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:10 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:35:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:35:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:38:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:08 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:38:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:38:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:14 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:38:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:38:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:14 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:38:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:38:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:38:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:33 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:38:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:38:39 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:38:39 --> Severity: error --> Exception: Call to undefined function verificarLimiteGanancias() C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Faturasmodel.php 274
ERROR - 2022-07-11 01:43:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:43:42 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:43:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:43:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:43:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:43:42 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:44:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:44:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:44:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:45:36 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:36 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:36 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:54 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:45:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:45:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:46:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:31 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:46:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:31 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:46:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:31 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:46:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:34 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:46:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:34 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:46:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:46:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:46:34 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:47:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:47:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:47:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:48:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:48:02 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:48:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 01:48:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:48:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:18 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 01:48:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 01:48:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 01:48:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 01:48:21 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 02:03:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:03:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:03:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:35 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:03:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:54 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:03:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:54 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:03:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:03:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:04:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:01 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:05 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:30 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:45 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:51 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:04:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:04:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:04:53 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:04:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:04:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:04:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:04:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:04:57 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 02:05:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:12 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:05:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:05:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:38 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 02:05:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 02:05:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:13:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:13:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión.
 C:\xampp\htdocs\proyecto_cero_desarrollo\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-07-11 21:13:50 --> Unable to connect to the database
ERROR - 2022-07-11 21:13:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión.
 C:\xampp\htdocs\proyecto_cero_desarrollo\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-07-11 21:13:54 --> Unable to connect to the database
ERROR - 2022-07-11 21:13:54 --> Query error: No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión.
 - Invalid query: SELECT *
FROM `usuarios`
WHERE `id` IS NULL
ERROR - 2022-07-11 21:13:54 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\usuarios_helper.php 27
ERROR - 2022-07-11 21:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:14:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:14:22 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:34:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:34:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:34:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:38:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:04 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-11 21:39:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:39:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:39:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:39:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:39:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:39:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:40:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:40:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:40:06 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:40:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:40:36 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:40:37 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:40:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:42:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:42:28 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:42:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:42:28 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:42:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:42:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:42:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:42:28 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:43:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:43:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:43:17 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:43:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:43:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:43:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:43:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:43:23 --> Severity: Notice --> Undefined property: Faturas::$Rangomodel C:\xampp\htdocs\proyecto_cero_desarrollo\system\core\Model.php 77
ERROR - 2022-07-11 21:43:23 --> Severity: error --> Exception: Call to a member function comprasPaqueteFacturaUsuario() on null C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Faturasmodel.php 382
ERROR - 2022-07-11 21:46:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:46:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:23 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:46:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:23 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:46:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:24 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:46:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:24 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:46:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:46:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:46:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:47:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:12 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:47:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:47:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:47:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:47:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:47:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:13 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:47:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:16 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:47:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:16 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:47:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:16 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:47:16 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:47:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:16 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:47:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:47:17 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:48:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:50 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:48:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:51 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:48:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:48:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:48:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:37 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:38 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:49:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:45 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:49:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:45 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:49:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:49:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:45 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:49:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:49:46 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:50:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:34 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:50:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:35 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:50:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:50:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:35 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:50:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:35 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:50:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:50:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:41 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:50:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:50:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:41 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:50:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:50:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:41 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:50:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:50:42 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:52:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:52:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:52:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:53:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:53:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:53:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:13 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:53:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:13 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:14 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:53:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:26 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:53:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:53:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:26 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:53:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:26 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:27 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:53:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:31 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:53:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:31 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:53:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:31 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:53:31 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:31 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:53:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:53:32 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-11 21:54:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:11 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:11 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:25 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:27 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:31 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:31 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:31 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:31 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:54:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:47 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:47 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:47 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:47 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:50 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:50 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:50 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:56 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:56 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:58 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:58 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:54:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:54:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:58 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:54:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:54:59 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:56:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:38 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:38 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:44 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:56:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:56:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:53 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:56:53 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:56:53 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:07 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:07 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:57:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:07 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:57:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:13 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:57:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:14 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:57:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:32 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:32 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:40 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:57:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:57:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:57:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:58:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:07 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:58:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:07 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:58:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:07 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:12 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:12 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:58:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 21:58:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:41 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 21:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 21:58:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:58:50 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:59:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:59:17 --> Could not find the language line "plans"
ERROR - 2022-07-11 21:59:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 21:59:43 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:05 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:06 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:00:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:35 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:35 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:00:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:35 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:00:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:37 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:37 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:00:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:38 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:00:38 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:00:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:00:38 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:02:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:29 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:29 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:34 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:02:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:55 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:02:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:55 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:02:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:59 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:59 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:02:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:02:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:59 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:02:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:02:59 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:04:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:04:58 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:04:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:04:58 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:05:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:05:06 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:05:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:05:07 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:05:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:05:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:06:07 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:06:08 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:28 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:18:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:18:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:18:51 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:18:51 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:19:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:06 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:19:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:06 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:19:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:06 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:19:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:06 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:19:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:09 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:19:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:09 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:19:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:19:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:09 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:19:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:09 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:19:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:49 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:19:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:19:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:19:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:19:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:19:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:19:50 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:19:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:19:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:20:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:20:01 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:20:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:20:46 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:20:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:20:57 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:13 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:21:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:15 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:21:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:21:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:21:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:22:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:21 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:22:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:21 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:22:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:22 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:22:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:24 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:24 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:22:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:24 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:22:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:24 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:22:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:22:55 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:23:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:23:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:18 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:23:18 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:18 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:23:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:28 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:28 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:23:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:28 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:23:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:23:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:23:28 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:24:47 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:24:47 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:24:47 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:25:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:12 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:25:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:25:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:25:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:25:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:12 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:25:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:25:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:23 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:25:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:25:24 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:25:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:25:24 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:27:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:04 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:05 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:18 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:20 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 22:27:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:48 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:48 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:27:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:48 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:27:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 22:27:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 22:27:56 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 22:27:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 22:27:56 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-11 23:04:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:04:46 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:04:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:04:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:04:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:04:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:04:56 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '130'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '131'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '132'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '133'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '134'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '136'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '137'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '127'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '3', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '127|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '128'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '130'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '131'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '132'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '133'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '134'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '136'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '137'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '138'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '139'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '145'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '138'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '139'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '143'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '144'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '146'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '147'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '143'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '144'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56'
WHERE `estado` = 1
AND `id` = '149'
ERROR - 2022-07-11 23:04:56 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:56', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '150'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '146'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '147'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '151'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '152'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '151'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '152'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '149'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '150'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '155'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '155|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '156'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '158'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '158|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '159'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '161'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '161|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '162'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '164'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '164|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '165'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '167'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '168'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '167|168|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '169'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '171'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '172'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '171|172|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '173'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '175'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '176'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '175|176|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '177'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '179'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '179|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '180'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `id_patrocinador` = '129', `id_factura` = '319', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '182'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '344', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '183'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '231', `id_patrocinador` = '229', `id_factura` = '337', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '184'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 2.3, `ganancia_diaria` = 0.046, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '183|184|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '185'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '233', `id_patrocinador` = '230', `id_factura` = '343', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57'
WHERE `estado` = 1
AND `id` = '187'
ERROR - 2022-07-11 23:04:57 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '187|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:04:57', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '188'
ERROR - 2022-07-11 23:05:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:05:03 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:05:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:05:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:05:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:05:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:08:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:08:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:08:31 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:09:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:33 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '125'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '3', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '125|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '126'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '127'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '3', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '127|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '128'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '3', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '127|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '129'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '130'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '131'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '130'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '131'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '132'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '133'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '134'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '135'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '136'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '137'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '132'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '133'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '134'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '136'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '137'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '138'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '139'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '140'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '141'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '127'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '3', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '127|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '128'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '130'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '131'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '132'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '133'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '134'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '3', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '132|133|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '142'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '136'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '137'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '138'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '139'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '143'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '144'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '3', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '145'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '146'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '147'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '145'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '138'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '139'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '143'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '144'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '149'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '150'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '146'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '147'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '151'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '152'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '3', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 3
WHERE `estado` = 1
AND `id` = '148'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '143'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '143|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '144'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '149'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '150'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '153'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '146'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '146|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '147'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '151'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '152'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '154'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '151'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '151|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '152'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '149'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '149|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '150'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '155'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '155|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '156'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '155|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '157'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '155'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '155|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '156'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '158'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '158|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '159'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '158|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '160'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '158'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '158|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '159'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '161'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '161|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '162'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '161|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '163'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '161'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '161|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '162'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '164'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '164|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '165'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '164|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '166'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '164'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '164|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '165'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '167'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '168'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '167|168|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '169'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '167|168|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '170'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '167'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '168'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '167|168|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '169'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '171'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '172'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '171|172|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '173'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '171|172|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '174'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '171'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '172'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '171|172|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '173'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '175'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '176'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '175|176|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '177'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '175|176|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '178'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '175'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '176'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '175|176|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '177'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '179'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '179|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '180'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '179|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '181'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '179'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '179|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '180'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `id_patrocinador` = '129', `id_factura` = '319', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '182'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `id_patrocinador` = '129', `id_factura` = '319', `id_plan` = '89327541', `valor_plan` = '50.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '182'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '344', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '183'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '231', `id_patrocinador` = '229', `id_factura` = '337', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '184'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 2.3, `ganancia_diaria` = 0.046, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '183|184|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '185'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '129', `porcentaje` = '2', `valor_plan` = 2.3, `ganancia_diaria` = 0.046, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '183|184|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '186'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '344', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '183'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '231', `id_patrocinador` = '229', `id_factura` = '337', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '184'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 2.3, `ganancia_diaria` = 0.046, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '183|184|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '185'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '233', `id_patrocinador` = '230', `id_factura` = '343', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '187'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '187|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '188'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '187|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '189'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '233', `id_patrocinador` = '230', `id_factura` = '343', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33'
WHERE `estado` = 1
AND `id` = '187'
ERROR - 2022-07-11 23:09:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '187|', `fecha_calculo` = '2022-07-11', `fecha_recalculo` = '2022-07-11 23:09:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '188'
ERROR - 2022-07-11 23:09:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:42 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:09:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:09:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:48 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:09:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:09:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:09:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> Could not find the language line "plans"
ERROR - 2022-07-11 23:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\financeiro\extrato.php 84
ERROR - 2022-07-11 23:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-11 23:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-11 23:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-11 23:10:09 --> 404 Page Not Found: Assets/template
