<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-10 08:02:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:02:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:02:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:02:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:02:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:02:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 08:09:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:09:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '1|2|', '2022-07-10', '2022-07-10 08:09:49')
ERROR - 2022-07-10 08:09:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '3|', '2022-07-10', '2022-07-10 08:09:49')
ERROR - 2022-07-10 08:09:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '3|', '2022-07-10', '2022-07-10 08:09:49')
ERROR - 2022-07-10 08:09:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '4|', '2022-07-10', '2022-07-10 08:09:49')
ERROR - 2022-07-10 08:09:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '4|', '2022-07-10', '2022-07-10 08:09:49')
ERROR - 2022-07-10 08:10:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:10:17 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '1|2|', '2022-07-10', '2022-07-10 08:10:17')
ERROR - 2022-07-10 08:10:17 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '3|', '2022-07-10', '2022-07-10 08:10:17')
ERROR - 2022-07-10 08:10:17 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '3|', '2022-07-10', '2022-07-10 08:10:17')
ERROR - 2022-07-10 08:10:17 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '4|', '2022-07-10', '2022-07-10 08:10:17')
ERROR - 2022-07-10 08:10:17 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '4|', '2022-07-10', '2022-07-10 08:10:17')
ERROR - 2022-07-10 08:11:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:11:59 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:11:59')
ERROR - 2022-07-10 08:11:59 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:11:59')
ERROR - 2022-07-10 08:11:59 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:11:59')
ERROR - 2022-07-10 08:11:59 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:11:59')
ERROR - 2022-07-10 08:11:59 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:11:59')
ERROR - 2022-07-10 08:13:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:13:43 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:13:43')
ERROR - 2022-07-10 08:13:43 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:13:43')
ERROR - 2022-07-10 08:13:43 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:13:43')
ERROR - 2022-07-10 08:13:44 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:13:43')
ERROR - 2022-07-10 08:13:44 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:13:43')
ERROR - 2022-07-10 08:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:14:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:14:23')
ERROR - 2022-07-10 08:14:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:14:23')
ERROR - 2022-07-10 08:14:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:14:23')
ERROR - 2022-07-10 08:14:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:14:23')
ERROR - 2022-07-10 08:14:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:14:23')
ERROR - 2022-07-10 08:15:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:15:07 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:15:07')
ERROR - 2022-07-10 08:15:07 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('47', 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:15:07')
ERROR - 2022-07-10 08:15:07 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:15:07')
ERROR - 2022-07-10 08:15:07 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES ('104', 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:15:07')
ERROR - 2022-07-10 08:15:07 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:15:07')
ERROR - 2022-07-10 08:16:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:16:01 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:16:01')
ERROR - 2022-07-10 08:16:01 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:16:01')
ERROR - 2022-07-10 08:16:01 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:16:01')
ERROR - 2022-07-10 08:16:01 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:16:01')
ERROR - 2022-07-10 08:16:01 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:16:01')
ERROR - 2022-07-10 08:16:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:16:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:16:23')
ERROR - 2022-07-10 08:16:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:16:23')
ERROR - 2022-07-10 08:16:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:16:23')
ERROR - 2022-07-10 08:16:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:16:23')
ERROR - 2022-07-10 08:16:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:16:23')
ERROR - 2022-07-10 08:17:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:19 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:19')
ERROR - 2022-07-10 08:17:19 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:19')
ERROR - 2022-07-10 08:17:19 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:19')
ERROR - 2022-07-10 08:17:19 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:19')
ERROR - 2022-07-10 08:17:19 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:19')
ERROR - 2022-07-10 08:17:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:21 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:21')
ERROR - 2022-07-10 08:17:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:22 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:22')
ERROR - 2022-07-10 08:17:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:23')
ERROR - 2022-07-10 08:17:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:23')
ERROR - 2022-07-10 08:17:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:23')
ERROR - 2022-07-10 08:17:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:23')
ERROR - 2022-07-10 08:17:23 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:23')
ERROR - 2022-07-10 08:17:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:27 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:27')
ERROR - 2022-07-10 08:17:27 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:27')
ERROR - 2022-07-10 08:17:27 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:27')
ERROR - 2022-07-10 08:17:27 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:27')
ERROR - 2022-07-10 08:17:27 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:27')
ERROR - 2022-07-10 08:17:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:47 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:47')
ERROR - 2022-07-10 08:17:47 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:47')
ERROR - 2022-07-10 08:17:47 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:47')
ERROR - 2022-07-10 08:17:47 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:47')
ERROR - 2022-07-10 08:17:47 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:47')
ERROR - 2022-07-10 08:17:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:48 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:48')
ERROR - 2022-07-10 08:17:48 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:48')
ERROR - 2022-07-10 08:17:48 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:48')
ERROR - 2022-07-10 08:17:48 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:48')
ERROR - 2022-07-10 08:17:48 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:48')
ERROR - 2022-07-10 08:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:49 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:17:49')
ERROR - 2022-07-10 08:17:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:17:57 --> Severity: error --> Exception: Call to undefined function json() C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\rangos_helper.php 140
ERROR - 2022-07-10 08:18:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:18:04 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:18:04')
ERROR - 2022-07-10 08:18:04 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:04')
ERROR - 2022-07-10 08:18:04 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:04')
ERROR - 2022-07-10 08:18:04 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:04')
ERROR - 2022-07-10 08:18:04 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:04')
ERROR - 2022-07-10 08:18:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:18:25 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:18:25')
ERROR - 2022-07-10 08:18:25 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:25')
ERROR - 2022-07-10 08:18:25 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:25')
ERROR - 2022-07-10 08:18:25 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:25')
ERROR - 2022-07-10 08:18:25 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:25')
ERROR - 2022-07-10 08:18:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:18:26 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:18:26')
ERROR - 2022-07-10 08:18:26 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:26')
ERROR - 2022-07-10 08:18:26 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:18:26')
ERROR - 2022-07-10 08:18:26 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:26')
ERROR - 2022-07-10 08:18:26 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:18:26')
ERROR - 2022-07-10 08:19:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:19:00 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 3.2, 0.064, 1, 1, 1, '5|6|', '2022-07-10', '2022-07-10 08:19:00')
ERROR - 2022-07-10 08:19:00 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.4, 0.028, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:19:00')
ERROR - 2022-07-10 08:19:00 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:19:00')
ERROR - 2022-07-10 08:19:00 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `porcentaje`, `valor_plan`, `ganancia_diaria`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 2, 1.5, 0.03, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:19:00')
ERROR - 2022-07-10 08:19:00 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:19:00')
ERROR - 2022-07-10 08:19:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:19:24 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = 2, `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `nivel` = 1, `tipo_ganancia` = 1, `correlativo_ganancia` = 1, `id_rangos` = '5|6|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 08:19:24'
WHERE `id` IS NULL
ERROR - 2022-07-10 08:19:24 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = 2, `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `nivel` = 2, `tipo_ganancia` = 1, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 08:19:24'
WHERE `id` IS NULL
ERROR - 2022-07-10 08:19:24 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.4, 0.028, 2, 2, 1, 1, '7|', '2022-07-10', '2022-07-10 08:19:24')
ERROR - 2022-07-10 08:19:24 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = 2, `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `nivel` = 2, `tipo_ganancia` = 1, `correlativo_ganancia` = 1, `id_rangos` = '8|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 08:19:24'
WHERE `id` IS NULL
ERROR - 2022-07-10 08:19:24 --> Query error: Unknown column 'nivel' in 'field list' - Invalid query: INSERT INTO `ganancias_rangos` (`id_usuario`, `valor_plan`, `ganancia_diaria`, `porcentaje`, `nivel`, `tipo_ganancia`, `correlativo_ganancia`, `id_rangos`, `fecha_calculo`, `fecha_registro`) VALUES (46, 1.5, 0.03, 2, 2, 1, 1, '8|', '2022-07-10', '2022-07-10 08:19:24')
ERROR - 2022-07-10 08:21:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:23:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:24:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:25:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:28:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:30:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:31:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:32:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 08:36:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:01:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:01:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:01:22 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:01:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:01:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:01:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:09:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:09:23 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: select *
                                     from ganancias_rangos
                                    where id = 1
                                      and tipo_ganancia > 1
                                      and estado = 1
                                    order by fecha asc
ERROR - 2022-07-10 09:09:23 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Usuariosmodel.php 198
ERROR - 2022-07-10 09:10:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:10 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:10:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:16 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:10:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:10:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:12:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:12:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:12:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:12:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:14:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:27 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:14:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:14:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:14:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:19:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:19:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:19:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:21:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = 46, `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49'
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = 46, `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49'
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '44|45|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '47|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '47|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49'
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '50|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-10 09:21:49 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '50|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:21:49', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-10 09:43:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:43:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:43:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:44:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:44:02 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = 46, `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 09:44:02', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-10 09:44:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:44:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:44:06 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:45:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:45:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:45:02 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:47:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:47:42 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\admin\usuarios\visualizar.php 318
ERROR - 2022-07-10 09:47:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:47:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:47:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:49:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:49:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:49:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:50:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:50:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:50:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:51:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:51:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:51:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:57:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:57:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:57:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 09:58:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:58:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 09:58:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:11:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:11:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
                                     from ganancias_rangos
              ...' at line 1 - Invalid query: select case when estado_ganancia = 1 then 'PENDING PAYMENT' else 'PAYMENT MADE' end as estado, *
                                     from ganancias_rangos
                                    where id_usuario = 46
                                      and tipo_ganancia > 1
                                      and estado_ganancia = 1
                                    order by fecha_calculo asc
ERROR - 2022-07-10 10:11:47 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Usuariosmodel.php 198
ERROR - 2022-07-10 10:11:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:11:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:11:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:12:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:12:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:12:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:44:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:44:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:44:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:44:31 --> 404 Page Not Found: admin/Rangos/calcular
ERROR - 2022-07-10 10:46:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:46:03 --> Severity: error --> Exception: Call to undefined function verificarPermisosUsuario() C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 24
ERROR - 2022-07-10 10:46:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:46:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:46:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:46:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:46:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:46:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:55:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:55:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 110
ERROR - 2022-07-10 10:55:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:55:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\admin\rangos\calcular.php 53
ERROR - 2022-07-10 10:55:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:55:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 10:58:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:58:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 10:58:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:00:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:00:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:00:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:00:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:00:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:00:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:11:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:11:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:11:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:14:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:15 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:14:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:14:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:14:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:14:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:20:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:20:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:21:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:21:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:22:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:22:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:22:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:22:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:22:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:22:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:23:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:23:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:23:06 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:23:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:23:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:23:38 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:24:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:24:47 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:25:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:25:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:25:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:32:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:32:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:32:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:32:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:32:47 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:32:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:32:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:32:48 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 11:32:48 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 11:33:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:33:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:33:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:33:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:33:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:33:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 11:33:36 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 11:34:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:34:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:00 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 11:34:00 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 11:34:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:34:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:18 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 11:34:18 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 11:34:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:34:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:43 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 11:34:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:34:43 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 11:34:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:37:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:37:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:37:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:37:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:42:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:42:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:42:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:42:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '16'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '21|22|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '1|2|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '1|2|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '38|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '41|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '44|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '47|48|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '51|52|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '55|56|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11'
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-10 11:42:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '59|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 11:42:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-10 11:42:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:42:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:42:15 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:43:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:43:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:43:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:44:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:44:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:44:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 11:50:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:50:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 11:50:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:05:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '9'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '9|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '10'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '13'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '16'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '20'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '17'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '18'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '17|18|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '19'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '21|22|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '21|22|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '24'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '25'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '26'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '10', `porcentaje` = '3', `valor_plan` = 2.6, `ganancia_diaria` = 0.052, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '25|26|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '27'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '11'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '11|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '12'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '14'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '15'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '16'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '14|15|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '28'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '21'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '22'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '21|22|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '23'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '1|2|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '1|2|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '29'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '1'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '2'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '1|2|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '3'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '6'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '4'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '4|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '5'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '32'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '7'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '7|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '8'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '33'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '33|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '34'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '30'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '30|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '31'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '37'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '35'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '35|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '36'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '38|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '38|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '40'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '38'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '38|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '39'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '41|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '41|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '43'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '41'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '41|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '42'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '44|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '44|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '46'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '44'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '44|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '45'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '47|48|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '47|48|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '50'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '47'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '48'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '47|48|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '49'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '51|52|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '51|52|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '54'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '51'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '52'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '51|52|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '53'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '55|56|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '55|56|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '58'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '55'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '56'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '55|56|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '57'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '59|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '59|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '61'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11'
WHERE `estado` = 1
AND `id` = '59'
ERROR - 2022-07-10 12:05:11 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '59|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:05:11', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '60'
ERROR - 2022-07-10 12:05:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:05:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:05:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:09:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:09:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:09:43 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:09:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:09:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:46'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 12:09:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:46'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 12:09:46 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:46', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 12:09:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:09:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 12:09:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:09:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:09:48 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:12:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '10', `porcentaje` = '3', `valor_plan` = 2.6, `ganancia_diaria` = 0.052, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|79|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '85'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 12:12:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 12:12:01 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:01', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 12:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:12:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:12:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:15'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 12:12:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 12:12:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:15'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 12:12:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:15', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 12:12:15 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:15', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '10', `porcentaje` = '3', `valor_plan` = 2.6, `ganancia_diaria` = 0.052, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|79|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '85'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 12:12:16 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 12:12:16', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 12:12:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:12:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:12:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:13:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:13:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:13:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:14:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:01 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-10 12:14:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 12:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 12:14:11 --> 404 Page Not Found: Assets/pages
ERROR - 2022-07-10 13:34:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:34:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:34:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 13:57:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '10', `porcentaje` = '3', `valor_plan` = 2.6, `ganancia_diaria` = 0.052, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '78|79|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '80'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '85'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 3.2, `ganancia_diaria` = 0.064, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '82|83|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '84'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 13:57:00 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 13:57:00', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 13:57:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:57:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:57:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 13:57:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:57:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:57:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 13:58:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:58:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 13:58:15 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 14:00:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:00:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:00:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 14:07:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 14:07:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 14:07:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:07:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 14:08:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:08:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:08:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:08:23 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:41 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:42 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:42 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:43 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:43 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:43 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:15:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:15:43 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:43 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:44 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:44 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:44 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:44 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:45 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:45 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:46 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:46 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:46 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:20:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:20:46 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:35 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:35 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:35 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:36 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:36 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:26:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:26:36 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:27:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:27:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:27:46 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:28:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:28:14 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 14:28:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 14:28:14 --> Severity: error --> Exception: Call to undefined function lang() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 19
ERROR - 2022-07-10 16:02:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:04 --> Could not find the language line "plans"
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 16:02:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:02:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 16:17:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:48 --> Could not find the language line "plans"
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:17:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 16:17:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 16:17:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:48:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:44 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:48:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:48:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:48:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:49:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:49:06 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:50:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:50:03 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:50:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:50:15 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:50:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:50:34 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:50:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:50:46 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:50:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:50:59 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:51:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:02 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\financeiro\extrato.php 84
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:51:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:51:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:52:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:52:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:53:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:21 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:53:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:53:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:53:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:21 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:53:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:22 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:53:22 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:53:22 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:53:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:53:22 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:55:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:56:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:41 --> Could not find the language line "plans"
ERROR - 2022-07-10 17:56:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 17:56:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:56:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:56:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 17:56:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 17:56:42 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 18:23:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:53 --> Could not find the language line "plans"
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 18:23:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:54 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 18:23:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 18:23:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:08:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:10 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:08:10 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 278
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:08:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:08:11 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:17 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:39 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:09:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:09:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:09:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:10:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:10:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:20:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:39 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:20:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:20:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:57 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:20:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:57 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:20:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:20:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:21:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:08 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 121
ERROR - 2022-07-10 19:21:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 185
ERROR - 2022-07-10 19:21:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 212
ERROR - 2022-07-10 19:21:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 212
ERROR - 2022-07-10 19:21:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:55 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:21:55 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:55 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:21:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:21:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:21:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:21:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:21:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:21:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:22:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:18 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 129
ERROR - 2022-07-10 19:22:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:19 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\cliente\Saquemodel.php 129
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:22:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:22:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:23:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:23:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:15 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:23:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:20 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:23:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:23:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:23:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:23:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:23:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:24:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:24:36 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:28:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:28:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:19 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:28:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:28:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:28:39 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:01 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:01 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:30 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:31 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:32 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:30:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:30:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:30:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:40 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:30:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:30:54 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:31:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:31:15 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:18 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:18 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:23 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:28 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:30 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:30 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:31 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:31 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:32 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:32 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:32 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:32 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:33 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:33 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:36 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:40:36 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:40:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:40:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:40:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:06 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:06 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:09 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:09 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:10 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:34 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:34 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:48 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:41:49 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:41:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:41:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:55:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:13 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:55:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:13 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:55:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:20 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:55:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:24 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:55:25 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:55:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:55:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:55:49 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:56:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:56:32 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:57:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:57:01 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:58:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:09 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:58:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:17 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:58:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:18 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:58:18 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 19:58:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 409
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:58:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:58:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> Could not find the language line "plans"
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 19:59:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 19:59:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:00:15 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:15 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:15 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:18 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:00:18 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:00:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 409
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:00:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:00:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:51 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:02:51 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:02:51 --> Severity: Warning --> Division by zero C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 409
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:52 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:02:56 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:02:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 409
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:02:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:02:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:03:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:58 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:03:58 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:03:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:03:59 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:12 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:04:12 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:04:56 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:04:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:04:56 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:07:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:27 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:07:27 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:07:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:07:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:07:28 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:07 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:08 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:43 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:10:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:43 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:43 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:44 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:44 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:45 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:10:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:10:46 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:11:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:03 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:11:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:11:04 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:12:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 198
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:12:02 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:12:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:12:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:14:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:16 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:14:16 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\cliente\backoffice\backoffice.php 196
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:23 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 20:14:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 20:14:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 21:09:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:09:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 21:09:26 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 21:50:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:50:09 --> 404 Page Not Found: Admim/rangos
ERROR - 2022-07-10 21:50:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:50:15 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php 23
ERROR - 2022-07-10 21:50:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:50:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:50:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: select *
                                     from usuarios
                                    where id = 
ERROR - 2022-07-10 21:50:23 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 121
ERROR - 2022-07-10 21:52:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:52:31 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:21 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:24 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:24 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:24 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:25 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:56:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:56:25 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:57:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:57:20 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:58:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:58:34 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:21 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:41 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:42 --> Could not find the language line "plans"
ERROR - 2022-07-10 21:59:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 21:59:57 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:00:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:00:26 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:00:46 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:00:46 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:50 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:51 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:51 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:52 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:02:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:02:57 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:09 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:21 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:03:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:03:23 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:21:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:21:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:21:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:22:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:22:52 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:22:52 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:22:52'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:22:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and status > 0
                                     order by data_pagamento ...' at line 4 - Invalid query: select *
                                     from faturas
                                    where id_usuario = 
                                      and status > 0
                                     order by data_pagamento desc
                                     limit 1
ERROR - 2022-07-10 22:22:52 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 36
ERROR - 2022-07-10 22:23:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:23:18 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:23:18 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:23:18'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:23:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and status > 0
                                     order by data_pagamento ...' at line 4 - Invalid query: select *
                                     from faturas
                                    where id_usuario = 
                                      and status > 0
                                     order by data_pagamento desc
                                     limit 1
ERROR - 2022-07-10 22:23:18 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\proyecto_cero_desarrollo\application\models\admin\Rangomodel.php 36
ERROR - 2022-07-10 22:25:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:25:58 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:25:58 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:25:58', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:26:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:26:44 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:27:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:27:25 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:31:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:22 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:31:22 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:22', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:31:47 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:47 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '320', `id_plan` = '89327536', `valor_plan` = '3000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47'
WHERE `estado` = 1
AND `id` = '123'
ERROR - 2022-07-10 22:31:47 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '123|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:31:47', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '124'
ERROR - 2022-07-10 22:31:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:31:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:31:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:32:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:10 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '320', `id_plan` = '89327536', `valor_plan` = '3000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10'
WHERE `estado` = 1
AND `id` = '123'
ERROR - 2022-07-10 22:32:10 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '123|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:10', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '124'
ERROR - 2022-07-10 22:32:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:13 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:32:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:13 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:32:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:32:13 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:32:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:32:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:32:14 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:32:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:14 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:32:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:32:32 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:32'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:32', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '320', `id_plan` = '89327536', `valor_plan` = '3000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33'
WHERE `estado` = 1
AND `id` = '123'
ERROR - 2022-07-10 22:32:33 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '123|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:32:33', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '124'
ERROR - 2022-07-10 22:40:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:40:03 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '320', `id_plan` = '89327536', `valor_plan` = '3000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03'
WHERE `estado` = 1
AND `id` = '123'
ERROR - 2022-07-10 22:40:03 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '123|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:03', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '124'
ERROR - 2022-07-10 22:40:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:40:21 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `id_patrocinador` = '1', `id_factura` = '28', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '62'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '62|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '63'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '1', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '66'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '73'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '4', `id_patrocinador` = '3', `id_factura` = '8', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '70'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `id_patrocinador` = '3', `id_factura` = '50', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '71'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '70|71|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '72'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '77'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '11', `id_patrocinador` = '10', `id_factura` = '14', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '78'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '12', `id_patrocinador` = '10', `id_factura` = '15', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '79'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `id_patrocinador` = '26', `id_factura` = '29', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '64'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 1.1, `ganancia_diaria` = 0.022, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '64|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '65'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '3', `id_patrocinador` = '2', `id_factura` = '7', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '67'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '21', `id_patrocinador` = '2', `id_factura` = '21', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '68'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '2', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '69'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '26', `porcentaje` = '2', `valor_plan` = 2.4, `ganancia_diaria` = 0.048, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '67|68|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '81'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `id_patrocinador` = '45', `id_factura` = '51', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '74'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '48', `id_patrocinador` = '45', `id_factura` = '54', `id_plan` = '89327532', `valor_plan` = '100.00', `porcentaje` = NULL, `ganancia_diaria` = '1.10', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '75'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '45', `porcentaje` = '2', `valor_plan` = 2.2, `ganancia_diaria` = 0.044, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '74|75|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '76'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `id_patrocinador` = '46', `id_factura` = '170', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '82'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `id_patrocinador` = '46', `id_factura` = '169', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '83'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '46', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '88'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `id_patrocinador` = '47', `id_factura` = '161', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '86'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '86|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '87'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '47', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '93'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `id_patrocinador` = '104', `id_factura` = '155', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '89'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '104', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '89|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '90'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '106', `id_patrocinador` = '105', `id_factura` = '157', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '94'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '105', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '94|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '95'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `id_patrocinador` = '108', `id_factura` = '163', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '91'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '91|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '92'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '108', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '98'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `id_patrocinador` = '109', `id_factura` = '172', `id_plan` = '89327534', `valor_plan` = '600.00', `porcentaje` = NULL, `ganancia_diaria` = '1.30', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '96'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.3, `ganancia_diaria` = 0.026, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '96|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '97'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '109', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '101'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `id_patrocinador` = '110', `id_factura` = '205', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '99'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.2, `ganancia_diaria` = 0.024, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '99|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '100'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '110', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '104'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `id_patrocinador` = '112', `id_factura` = '174', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '102'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.6, `ganancia_diaria` = 0.032, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '102|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '103'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '112', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '107'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `id_patrocinador` = '113', `id_factura` = '203', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '105'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 1.4, `ganancia_diaria` = 0.028, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '105|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '106'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '113', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '111'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `id_patrocinador` = '114', `id_factura` = '192', `id_plan` = '89327533', `valor_plan` = '300.00', `porcentaje` = NULL, `ganancia_diaria` = '1.20', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '108'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '116', `id_patrocinador` = '114', `id_factura` = '202', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '109'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 2.8, `ganancia_diaria` = 0.056, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '108|109|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '110'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '114', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '115'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '117', `id_patrocinador` = '115', `id_factura` = '190', `id_plan` = '89327535', `valor_plan` = '1000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.40', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '112'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `id_patrocinador` = '115', `id_factura` = '201', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '113'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3, `ganancia_diaria` = 0.06, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '112|113|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '114'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '115', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '119'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `id_patrocinador` = '119', `id_factura` = '200', `id_plan` = '89327539', `valor_plan` = '20000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.60', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '116'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '122', `id_patrocinador` = '119', `id_factura` = '199', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '117'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 3.1, `ganancia_diaria` = 0.062, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '116|117|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '118'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '119', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 3, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 2
WHERE `estado` = 1
AND `id` = '122'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '121', `id_patrocinador` = '120', `id_factura` = '196', `id_plan` = '89327538', `valor_plan` = '10000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '120'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '120', `porcentaje` = '1', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '120|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '121'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '230', `id_patrocinador` = '229', `id_factura` = '320', `id_plan` = '89327536', `valor_plan` = '3000.00', `porcentaje` = NULL, `ganancia_diaria` = '1.50', `correlativo` = 1, `tipo_ganancia` = 1, `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21'
WHERE `estado` = 1
AND `id` = '123'
ERROR - 2022-07-10 22:40:21 --> Query error: Unknown column 'estado' in 'where clause' - Invalid query: UPDATE `ganancias_rangos` SET `id_usuario` = '229', `porcentaje` = '2', `valor_plan` = 1.5, `ganancia_diaria` = 0.03, `tipo_ganancia` = 2, `correlativo_ganancia` = 1, `id_rangos` = '123|', `fecha_calculo` = '2022-07-10', `fecha_recalculo` = '2022-07-10 22:40:21', `nivel_ganancia` = 1
WHERE `estado` = 1
AND `id` = '124'
ERROR - 2022-07-10 22:46:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:46:38 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:46:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:46:39 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:46:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:46:54 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:01 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:07 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:07 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:07 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:26 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:27 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:27 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:28 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:29 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:29 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:47:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:47:29 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:48:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:25 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:48:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:36 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:48:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:48:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:56 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:48:57 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:48:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:48:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:20 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:33 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:49:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:36 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> Could not find the language line "plans"
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 22:49:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 22:49:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:05:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:05:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 23:05:01 --> 404 Page Not Found: Assets/template
ERROR - 2022-07-10 23:10:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:29 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:29 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:36 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:37 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:42 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:42 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:43 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:50 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:51 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:52 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:10:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:58 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:10:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:10:59 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:10:59 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:11:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:11:09 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:11:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:11:09 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:11:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:11:09 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:11:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:11:09 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:11:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:11:10 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:13:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:08 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:13:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:13:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:13:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:40 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:13:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:40 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:13:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:13:40 --> Could not find the language line "plans"
ERROR - 2022-07-10 23:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:14:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:14:00 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:14:00 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:14:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:14 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:14 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:15:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:21 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:15:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:21 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:15:21 --> 404 Page Not Found: Assets/bower_components
ERROR - 2022-07-10 23:15:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:27 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-10 23:15:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:27 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-10 23:15:27 --> 404 Page Not Found: Assets/assets
ERROR - 2022-07-10 23:15:27 --> 404 Page Not Found: Assets/bower_components
