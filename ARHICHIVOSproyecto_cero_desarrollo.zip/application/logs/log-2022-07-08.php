<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-08 19:40:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 19:40:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 19:49:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 19:49:38 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\script\ejecutar.php 52
ERROR - 2022-07-08 19:50:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 19:50:31 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\script\ejecutar.php 33
ERROR - 2022-07-08 19:50:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 19:50:36 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\proyecto_cero_desarrollo\application\views\script\ejecutar.php 33
ERROR - 2022-07-08 20:57:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 20:58:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 20:58:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:05:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:05:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:05:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:06:32 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:06:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:06:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:06:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:08:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:09:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:09:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:10:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:10:31 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\rangos_helper.php 23
ERROR - 2022-07-08 21:10:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:11:59 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:12:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:12:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\rangos_helper.php 28
ERROR - 2022-07-08 21:12:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:13:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:14:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:15:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:15:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:19:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:19:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:21:42 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:21:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:23:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:23:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:23:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:24:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:26:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:31:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:34:49 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:34:49 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\rangos_helper.php 17
ERROR - 2022-07-08 21:34:58 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:34:58 --> Severity: error --> Exception: Too few arguments to function calcularRangos(), 1 passed in C:\xampp\htdocs\proyecto_cero_desarrollo\application\controllers\admin\Rangos.php on line 16 and exactly 4 expected C:\xampp\htdocs\proyecto_cero_desarrollo\application\helpers\rangos_helper.php 2
ERROR - 2022-07-08 21:35:13 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:36:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:37:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:37:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:38:37 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:39:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:40:52 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:41:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:42:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:43:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:43:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:43:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:44:44 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:53:08 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:54:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 21:55:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:01:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:03:25 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:04:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:05:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:05:10 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:06:43 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-08 22:14:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
