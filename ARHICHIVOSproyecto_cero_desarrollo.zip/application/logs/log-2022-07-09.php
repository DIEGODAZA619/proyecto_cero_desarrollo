<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-09 14:36:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:36:22 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:36:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:36:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:36:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:36:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:15 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:37:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:39:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:39:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:39:33 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:39:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:39:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:39:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:45:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:45:51 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:45:51 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:45:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:45:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:45:53 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:49:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:00 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:49:00 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:09 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:16 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:17 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:17 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:49:19 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 14:51:53 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:51:54 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:51:56 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:52:01 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:52:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:52:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:52:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 14:52:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:30 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:30 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:08:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:36 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:36 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:08:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:08:38 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:23 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:24 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:24 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:26 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:09:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:09:41 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:12:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:07 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:07 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:12:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:18 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:18 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:12:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:39 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:12:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:50 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:12:50 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:13:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:13:12 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:13:12 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:14:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:02 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:14:04 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:05 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:14:05 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:11 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:19 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:21 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:33 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:34 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:14:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:14:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:38 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:14:38 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 15:15:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:15:20 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 15:28:41 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:26 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:31 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:31 --> 404 Page Not Found: admin/R/index
ERROR - 2022-07-09 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:34 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:39 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:40 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:40 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 22:02:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:45 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:45 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 22:02:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:02:48 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:02 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:03 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:03 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 22:03:28 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:29 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:29 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 22:03:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:35 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:03:35 --> 404 Page Not Found: Vendor/needim
ERROR - 2022-07-09 22:04:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:04:06 --> Could not find the specified $config['composer_autoload'] path: C:\xampp\htdocs\proyecto_cero_desarrollo\vendor/autoload.php
ERROR - 2022-07-09 22:04:06 --> 404 Page Not Found: Vendor/needim
