<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['support']='지원';
    $lang['create']='티켓 생성';
    $lang['subject']='주제';
    $lang['last_update']='마지막 업데이트';
    $lang['status']='상태';
    $lang['toview']='보기';
    $lang['closed']='닫은';
?>



<?php //echo lang('plans')?>