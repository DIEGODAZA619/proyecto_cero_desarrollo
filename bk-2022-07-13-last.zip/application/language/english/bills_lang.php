<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['invoices']='Bills';
    $lang['plan']='Plan';
    $lang['price']='Price';
    $lang['check']='Check on Etherscan';
    $lang['state']='State';
    $lang['voucher']='Voucher';

?>



<?php //echo lang('plans')?>