<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['bynary_network']='Binary NetWork';
    $lang['boton1']='Back to my Network';
    $lang['boton2']='Go back one Level';


?>


 