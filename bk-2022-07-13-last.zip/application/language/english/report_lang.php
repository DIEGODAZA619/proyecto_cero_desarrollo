<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['earnings_report']='Earnings Report';
    $lang['descrip']='Description';
    $lang['price']='Price';
    $lang['date']='Date';

?>



 