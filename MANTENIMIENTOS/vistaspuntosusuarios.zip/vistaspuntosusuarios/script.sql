INSERT INTO opciones(id,id_modulo, codigo_opciones, opcion, link, icono, nivel, orden, estado) 
VALUES (24,0,13,'User-plan- puntos iz y puntos derecha','admin/puntos','',2,5,'AC');


INSERT INTO usuarios_opciones(id_opcion, id_usuario) 
VALUES (24,1);