<!--main content start-->
<div id="content" class="ui-content">
    <div class="ui-content-body">
        <div class="ui-container">
            <!--page title and breadcrumb start -->
            <div class="row">
                <div class="col-md-8">
                    <h1 class="page-title"> Notificações para administração
                        <small>todas as notificações para os administradores verificar</small>
                    </h1>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb pull-right">
                        <li>Home</li>
                        <li>Notificações</li>
                        <li><a href="<?php echo base_url('admin/notificacoes/admin');?>" class="active">Notificações para Administração</a></li>
                    </ul>
                </div>
            </div>
            <!--page title and breadcrumb end -->

            <div class="row">
              <div class="col-sm-12">
                  <section class="panel">
                      <div class="panel-body">
                          <table class="table responsive-data-table table-striped">
                              <thead>
                              <tr>
                                  <th>
                                      Notificação
                                  </th>
                                  <th>
                                      Data
                                  </th>
                                  
                              </tr>
                              </thead>
                              <tbody>
                              <?php
                              if($notificacoes !== false){
                                foreach($notificacoes as $notificacao){
                              ?>
                              <tr>
                                  <td>
                                      <?php echo $notificacao->mensagem;?>
                                  </td>
                                  <td>
                                      <?php echo date('d/m/Y H:i:s', strtotime($notificacao->data)); ?>
                                  </td>
                              </tr>
                              <?php
                                }
                              }
                              ?>
                              </tbody>
                          </table>
                      </div>
                  </section>
              </div>

          </div>

        </div>

    </div>
</div>
<!--main content end-->