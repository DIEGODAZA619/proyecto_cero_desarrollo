<!--main content start-->
<div id="content" class="ui-content">
    <div class="ui-content-body">
        <div class="ui-container">
            <!--page title and breadcrumb start -->
            <div class="row">
                <div class="col-md-8">
                    <h1 class="page-title"> Adicionar método de pagamento
                        <small>adicionar uma nova conta</small>
                    </h1>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb pull-right">
                        <li>Home</li>
                        <li>Financeiro</li>
                        <li><a href="<?php echo base_url('admin/carreira/adicionar');?>" class="active">Adicionar conta para pagamento</a></li>
                    </ul>
                </div>
            </div>
            <!--page title and breadcrumb end -->
            
            <!-- page start-->
            <div class="row">
                <div class="col-sm-12">
                    <section class="panel">
                        <div class="panel-body">

                        <form action="" method="post" class="form-horizontal form-variance">
                          
                          <?php if(isset($message)) echo $message;?>
                          
                          <div class="form-group">
                              <label class="col-sm-3 control-label">Tipo de conta</label>
                              <div class="col-sm-6">
                                    <input type="radio" name="tipo" value="1" checked> Conta Bancária
                                    <input type="radio" name="tipo" value="2"> PIX
                              </div>
                          </div>

                          <div id="box_conta_bancaria" style="display:block;">
                            
                            <div class="form-group">
                              <label class="col-sm-3 control-label">Banco</label>
                              <div class="col-sm-6">
                                    <select name="banco" class="form-control">
                                      <?php
                                      foreach(Bancos() as $banco){
                                        echo '<option value="'.$banco['code'].'">'.$banco['code'].' - '.$banco['name'].'</option>';
                                      }
                                      ?>
                                    </select>
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">Agência</label>
                              <div class="col-sm-6">
                                    <input type="text" name="agencia" class="form-control">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">Conta</label>
                              <div class="col-sm-6">
                                    <input type="text" name="conta" class="form-control">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">Operação (opcional)</label>
                              <div class="col-sm-6">
                                    <input type="text" name="operacao" class="form-control">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">Tipo de Conta</label>
                              <div class="col-sm-6">
                                    <input type="radio" name="tipo_conta" value="1" checked> Conta Corrente
                                    <input type="radio" name="tipo_conta" value="2"> Conta Poupança
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">Titular</label>
                              <div class="col-sm-6">
                                    <input type="text" name="titular" class="form-control">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">WALLET/CNPJ</label>
                              <div class="col-sm-6">
                                    <input type="text" name="documento" class="form-control">
                              </div>
                          </div>

                          </div>

                          <div id="box_bitcoin" style="display:none;">
                            
                            <div class="form-group">
                              <label class="col-sm-3 control-label">Carteira</label>
                              <div class="col-sm-6">
                                    <input type="text" name="carteira" class="form-control">
                              </div>
                          </div>

                          </div>

                          <div class="form-group">
                              <label class="col-sm-3 control-label">&nbsp;</label>
                              <div class="col-sm-6">
                                    <input type="submit" name="submit" class="btn btn-success" value="Adicionar Pagamento">
                              </div>
                          </div>

                        </form>

                        </div>
                    </section>
                </div>
            </div>

        </div>

    </div>
</div>
<!--main content end-->